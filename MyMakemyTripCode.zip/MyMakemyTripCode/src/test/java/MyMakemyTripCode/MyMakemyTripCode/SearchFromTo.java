package MyMakemyTripCode.MyMakemyTripCode;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class SearchFromTo {
	
	WebDriver ldriver;
	
	public SearchFromTo(WebDriver rdriver)
	{
		ldriver=rdriver;
		PageFactory.initElements(rdriver,this);
	}
	
	@FindBy(xpath="//input[@id=\"fromCity\"]")
	@CacheLookup
	WebElement fromcity;
	
	
	@FindBy(xpath = "//input[@placeholder=\"From\"]")
	WebElement txtFROM;

	@FindBy(xpath="//input[@id=\"toCity\"]")
	@CacheLookup
	WebElement tocity;
	
	@FindBy(xpath="//input[@placeholder=\"To\"]")
	@CacheLookup
	WebElement txtTO;
	
	@FindBy(xpath="//a[text()=\"Search\"]")
	WebElement Searchbtn;
	
public void fromcity()
	
	{
	fromcity.click();	
	
	}
	
	public void setFrom(String From)
	
	{
		txtFROM.sendKeys(From);	
	}
	
public void Tocity()
	
	{
	tocity.click();
	
	}
public void setTo(String To)
	
	{
	txtTO.sendKeys(To);	
	}
public void setsearchbtn()

{
	Searchbtn.click();
}
	

}
