package MyMakemyTripCode.utilities;

import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;


public class ReadConfic {
	
	Properties pro;
	
	public ReadConfic()
	{
		File src =new File("./Configration/Config.properties");
		try
		{
			FileInputStream fis= new FileInputStream(src);
			pro =new Properties();
			pro.load(fis);
		}
		catch (Exception e){
			
			System.out.println("Exception is" + e.getMessage());
			
		}
	}
	
	public String getApplicationURL()
	{
		String url=pro.getProperty("baseURL");
		return url;
		
	}
	
	public String getfrom()
	{
		String from=pro.getProperty("From");
		return from;
		
	}
	
	public String getTo()
	{
		String To=pro.getProperty("To");
		return To;
		
	}
	
	public String getchromepath()
	{
		String Chrome=pro.getProperty("chromepath");
		return Chrome;
		
	}
	
	public String getfirefoxpath()
	{
		String fire=pro.getProperty("firefoxpath");
		return fire;
		
	}
	
	public String getiePath()
	{
		String IE=pro.getProperty("iePath");
		return IE;	
	}
	
	

}
