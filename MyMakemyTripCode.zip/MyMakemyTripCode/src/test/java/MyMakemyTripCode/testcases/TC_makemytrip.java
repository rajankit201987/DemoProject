package MyMakemyTripCode.testcases;

import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.testng.annotations.Test;	

import MyMakemyTripCode.MyMakemyTripCode.SearchFromTo;

public class TC_makemytrip extends BaseUrl {
	
	@Test
	public void searchTest()
	{
		
		driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
        logger.info("LunchURL");
        
		SearchFromTo sr=new SearchFromTo(driver);
		 driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
		
		sr.fromcity();
		 driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		 logger.info("clickFromCity");
		sr.setFrom(From);
		 driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		 logger.info("enterFrom");
		sr.Tocity();
		 driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		 logger.info("ClickToCity");
		sr.setTo(To);
		 driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		 logger.info("EnterToDetails");
		 
		 driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		 
		sr.setsearchbtn();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		logger.info("clickBtn");
		
		
	}

}
